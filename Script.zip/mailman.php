<?php

$mail = 'dioakun515@gmail.com'; // EMAIL KAMU

?>